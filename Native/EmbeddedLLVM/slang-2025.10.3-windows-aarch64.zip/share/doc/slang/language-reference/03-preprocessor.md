> Note: This document is a work in progress. It is both incomplete and, in many cases, inaccurate.

Preprocessor
============

Slang supports a C-style preprocessor with the following directives:

* `#include`
* `#define`
* `#undef`
* `#if`, `#ifdef`, `#ifndef`
* `#else`, `#elif`
* `#endif`
* `#error`
* `#warning`
* `#line`
* `#pragma`

> Note: This section is not yet complete.
